#!/bin/bash

python scripts/generate.py -s gl.xml -d ../glbinding -r gl.revision -p patch.xml
