#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl30ext/types.h>
#include <glbinding/gl30ext/boolean.h>
#include <glbinding/gl30ext/values.h>
#include <glbinding/gl30ext/bitfield.h>
#include <glbinding/gl30ext/enum.h>
#include <glbinding/gl30ext/functions.h>
