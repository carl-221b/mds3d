#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl44ext/types.h>
#include <glbinding/gl44ext/boolean.h>
#include <glbinding/gl44ext/values.h>
#include <glbinding/gl44ext/bitfield.h>
#include <glbinding/gl44ext/enum.h>
#include <glbinding/gl44ext/functions.h>
